@component('mail::message')
# Thank You for getting in contact with us.
## We will get back to You as soon as possible.

Thanks,<br>
{{ config('app.name') }}
@endcomponent
