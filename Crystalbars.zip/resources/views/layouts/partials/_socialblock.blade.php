<div class="row">
    <div class="md-col-12">
        <div class="social__block ">
            <h2 class="text--white">Please follow us on</h2>

            <a target="_blank" class="text--white" href="https://www.facebook.com/www.crystalbars.co.za/"><i class="lunacon lunacon--size-x3 lunacon-facebook"></i></a>
            {{-- <a target="_blank" class="text--white" href=""><i class="lunacon lunacon--size-x3 lunacon-google-plus"></i></a> --}}
            {{-- <a target="_blank" class="text--white" href=""><i class="lunacon lunacon--size-x3 lunacon-youtube"></i></a> --}}

            <div class="social__block__image"></div>
        </div>
    </div>
</div>
